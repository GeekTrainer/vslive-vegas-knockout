# Visual Studio Live
## Knockout demos
Here are the demos presented at Visual Studio Live in Las Vegas, NV.

### Installation instructions
Files downloaded via npm and bower.
~~~
npm install
bower-installer
~~~
